Could not get the magnifying glass to work correctly, but at least it magnifies...

dont worry about the "test3" name, its HW2.

with oculus quest controllers, press grip (trigger...?) when the red laser turns white when you point it at the magnifying glass

https://github.com/Metalluminous/Virtual3